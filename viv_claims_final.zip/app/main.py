from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from app.database import Base, engine
from app.db_init import init_db
from app.routes.auth_routes import router as auth_router
from app.routes.form_routes import router as form_router
import os  # ✅ This is now all you need

app = FastAPI()

# ✅ Environment Variables (from Render or local shell)
EMAIL_FROM = os.environ["EMAIL_FROM"]
SMTP_SERVER = os.environ["SMTP_SERVER"]
SMTP_PORT = int(os.environ["SMTP_PORT"])
SMTP_USER = os.environ["SMTP_USER"]
SMTP_PASSWORD = os.environ["SMTP_PASSWORD"]
APP_URL = os.environ["APP_URL"]

# ✅ Initialize DB & create tables
init_db()
Base.metadata.create_all(bind=engine)

# ✅ Mount static assets
app.mount("/static", StaticFiles(directory="app/static"), name="static")
app.mount("/finalized_pdfs", StaticFiles(directory="finalized_pdfs"), name="finalized_pdfs")

# ✅ Include your routers
app.include_router(auth_router)    # /login, /register, /logout
app.include_router(form_router)    # /, /claim-package, /clients, /admin/dashboard, etc.


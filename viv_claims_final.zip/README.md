# Valley Isle Valuations Contents Estimate Tool

## Setup
1. Create virtual env: `python -m venv venv`
2. Activate: `source venv/bin/activate`
3. Install: `pip install -r requirements.txt`
4. Run: `uvicorn app.main:app --reload`

## Usage
- Visit: `http://localhost:8000/claim-package`
- All PDFs are saved to `/finalized_pdfs`
